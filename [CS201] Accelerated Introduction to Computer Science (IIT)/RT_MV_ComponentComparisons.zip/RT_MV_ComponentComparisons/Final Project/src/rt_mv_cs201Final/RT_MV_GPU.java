package rt_mv_cs201Final;
/* Markiyan Varhola and Ryan S. Tan
 * CS 201 Spring 2015
 * Final Project
 * April 13, 2015
 */
//DOCUMENTATION - This Java class (GPU.java) is a child class to Component.java and extends much of its functionality, specifically to
//graphics processing unit (GPU) components. In contrast, the other child class to Component.java is CPU.java, which deals with central
//processing unit (CPU) components.


public class RT_MV_GPU extends RT_MV_Component {
	//initialize instance variables
	private String benchmarkScores; // array of benchmark scores (basically GPU test scores)
	private double vram; //variable for amount of memory inside the GPU
	private String socketType; //determines what other components the GPU is compatible with, important for PC builders
	
	public RT_MV_GPU() { // default constructor
		super();
		benchmarkScores = "NA";
		vram = 0;
		socketType = "N/A";
	}
	
	//nondefault constructor
	public RT_MV_GPU(int id, String name, String brand, double price, int reviewScore, String benchmarkScores, double vram, String socketType){
		super(id,name,brand,price,reviewScore);
		this.benchmarkScores = benchmarkScores;
		this.vram = vram;
		this.socketType = socketType;
	}
	
	public String getBenchmarkScores() { //accessors (getters)
		return benchmarkScores;
	}

	public double getClockSpeed() {
		return vram;
	}
	public String getSocketType() {
		return socketType;
	}
	
	public void setBenchmarkScores(String benchmarkScores) { //mutators (setters)
		this.benchmarkScores = benchmarkScores;
	}

	public void setVram(double vram) {
		this.vram = vram;
	}

	public void setSocketType(String socketType) {
		this.socketType = socketType;
	}
	
	public String toString(){
		return super.toString();
	}
}
