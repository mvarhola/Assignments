package rt_mv_cs201Final;

/* Markiyan Varhola
 * CS 201 Spring 2015
 * Final Project
 * April 21, 2015
 * Component.java - Parent class of all components with general functionality
 */
//


public class RT_MV_Component implements Comparable<RT_MV_Component>{

	private String name;
	private String brand;
	private double price;
	private int reviewScore;
	private int id;
	
	public RT_MV_Component(){
		name = "NA";
		brand = "unknown";
		price = 0.00;
		reviewScore = 0;
		id = -1;
	}

	public RT_MV_Component(int id, String name, String brand, double price, int reviewScore){
		this.id = id;
		this.name = name;
		this.brand = brand;
		this.price = price;
		this.reviewScore = reviewScore;
	}
	
	public void setId(int id){
		this.id = id;
	}
	
	public int getId(){
		return id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getReviewScore() {
		return reviewScore;
	}

	public void setReviewScore(int reviewScore) {
		this.reviewScore = reviewScore;
	}
	
	public boolean equals(RT_MV_Component x){
		
		return (name.equals(x.getName()) && brand.equals(x.getBrand()) && price == x.getPrice() && reviewScore == x.getReviewScore());
				
	}
	
	public String toString(){
		return String.format("%s\t%s\t%2f\t%d\n",name,brand,price,reviewScore); //tab delimited string with component info
	}
	
	//CompareTo compares by ID
	
	public int compareTo(RT_MV_Component x){
		if (id < x.getId()){
			return -1;
		}else if (id > x.getId()){
			return 1;
		}else{
			return 0;
		}
	}
	
	public int compareByName(RT_MV_Component x){
		return name.compareTo(x.getName());
	}
	
	public int compareByPrice(RT_MV_Component x){
		if (price < x.getPrice()){
			return -1;
		}else if (price > x.getPrice()){
			return 1;
		}else{
			return 0;
		}
	}
	
	public int compareByBrand(RT_MV_Component x){
		return brand.compareTo(x.getBrand());
	}
	
	public int compareByReviewScore(RT_MV_Component x){
		if (reviewScore < x.getReviewScore()){
			return -1;
		}else if (reviewScore > x.getReviewScore()){
			return 1;
		}else{
			return 0;
		}
	}
	
}
