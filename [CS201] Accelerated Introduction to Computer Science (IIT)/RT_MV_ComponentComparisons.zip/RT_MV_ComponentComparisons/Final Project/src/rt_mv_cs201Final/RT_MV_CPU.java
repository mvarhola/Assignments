package rt_mv_cs201Final;
/* Markiyan Varhola and Ryan S. Tan
 * CS 201 Spring 2015
 * Final Project
 * April 13, 2015
 */
//DOCUMENTATION - This Java class (CPU.java) is a child class to Component.java and extends much of its functionality, specifically to
//central processing unit (CPU) components. In contrast, the other child class to Component.java is GPU.java, which deals with graphics
// processing unit (GPU) components.

public class RT_MV_CPU extends RT_MV_Component {
	//initialize instance variables
	private String benchmarkScores; // array of benchmark scores (basically CPU test scores)
	private double clockSpeed; //variable for speed of internal clock, CPU-specific performance indicator
	private String socketType; //determines what other components the CPU is compatible with, important for PC builders
	

	public RT_MV_CPU() { // default constructor
		super();
		benchmarkScores = "NA";
		clockSpeed = 0.00;
		socketType = "N/A";
	}
	//"Name","Brand",price,type,rating 1-10,grade(gpu) or array of benchmarks (cpu),vram (gpu) or clock speed (cpu), "Socket type"

	//nondefault constructor
	public RT_MV_CPU(int id, String name, String brand, double price, int reviewScore, String benchmarkScores, double clockSpeed, String socketType){
		super(id, name,brand,price,reviewScore);
		setBenchmarkScores(benchmarkScores);
		this.clockSpeed = clockSpeed;
		this.socketType = socketType;
	}

	public String getBenchmarkScores() { // polymorphism, getter, returns average value of the 3 benchmark scores
		int averageBenchMark = 0;
		for (String x: benchmarkScores.replaceAll("\"","").split(" ")){
			averageBenchMark += Integer.parseInt(x);
		}
		return String.valueOf((averageBenchMark/3));
	}

	public void setBenchmarkScores(String benchmarkScores) { //setter
		this.benchmarkScores = benchmarkScores;
	}

	public double getClockSpeed() { //getter
		return clockSpeed;
	}

	public void setClockSpeed(double clockSpeed) { //setter
		this.clockSpeed = clockSpeed;
	}

	public String getSocketType() { //getter
		return socketType;
	}

	public void setSocketType(String socketType) { //setter
		this.socketType = socketType;
	}

	
	public String toString(){ //toString method
		return super.toString();
	}
	
}
