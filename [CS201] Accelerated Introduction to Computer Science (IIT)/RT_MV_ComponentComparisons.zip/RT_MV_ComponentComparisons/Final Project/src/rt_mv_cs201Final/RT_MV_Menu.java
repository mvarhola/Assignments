package rt_mv_cs201Final;
import java.util.Scanner; //necessary for user input
import java.io.*; //necessary for file input
/* Markiyan Varhola and Ryan S. Tan
 * CS 201 Spring 2015
 * Final Project
 * April 13, 2015
 */
//DOCUMENTATION - This Java class is meant to provide a command line interface menu for the user.


public class RT_MV_Menu{
	//declare instance variables
	private String inputFilename; //contains the name of the input file 
	private RT_MV_GenericList<RT_MV_Component> componentList; //declares the list of hardware components
	private String[] OPTIONS = {"Display...","Search...","Sort...","Add...","Delete...","Print Output to File","Quit"}; // the menu options users see
	private boolean done;
	
	public RT_MV_Menu(){ //default constructor
		inputFilename = "components.txt";
		componentList = new RT_MV_GenericList<RT_MV_Component>(100);
		readFile();
		done = false;
	}
	
	public RT_MV_Menu(String file){ //non-default constructor
		inputFilename = file;
		componentList = new RT_MV_GenericList<RT_MV_Component>(100);
		readFile();
		done = false;
	}
	
	
	public void readFile(){ // uses scanner to read in the file line-by-line. Each line is sent to the parseLine method
		File x = new File(inputFilename);
		try {
			Scanner y = new Scanner(x);
			while (y.hasNextLine()){
				String tempString = y.nextLine();
				parseLine(tempString);
			}
		} catch (FileNotFoundException e) {
			System.out.printf("File not found!");
		}
	}
	
	public void parseLine(String line){  // takes each scanned line of the input file and makes a GenericList object for it
		String testLine = line.split(",")[4]; //the split on 4 is a string that says what type the component is
		String[] currentList = line.split(",");
		if (testLine.equals("cpu")){ // if the component is a cpu type
			componentList.add(new RT_MV_CPU(	Integer.parseInt(currentList[0]),//id
										currentList[1].replaceAll("\"",""),//name
										currentList[2].replaceAll("\"",""),//brand
										Double.parseDouble(currentList[3]),//price
										Integer.parseInt(currentList[5]),//reviewScore
										currentList[6].replaceAll("\"",""),//benchmarkScore
										Double.parseDouble(currentList[7]),//clockSpeed
										currentList[8].replaceAll("\"","")));//socketType
		}
		else if (testLine.equals("gpu")){ // if the component is a gpu type
			componentList.add(new RT_MV_GPU(	Integer.parseInt(currentList[0]),//id
										currentList[1].replaceAll("\"",""),//name
										currentList[2].replaceAll("\"",""),//brand
										Double.parseDouble(currentList[3]),//price
										Integer.parseInt(currentList[5]),//reviewScore
										currentList[6].replaceAll("\"",""),//benchmarkScore
										Double.parseDouble(currentList[7]),//clockSpeed
										currentList[8].replaceAll("\"","")));//socketType
		}
	}
	
	public void listOptions(String[] options){
		for (int i = 0; i < options.length; i++){
			System.out.printf("%d). %s\t",i,options[i]);
		}
	}
	
	
	public boolean getProgramStatus(){
		return done;
	}
	
	public int getInput(){ // allows user to input an int, then gives an error if it's not valid
		Scanner x = new Scanner(System.in);
		System.out.println();
		System.out.print(">>> ");
		int choice = -1;
		if (x.hasNextInt()){
			choice = x.nextInt();
		}else{
			System.out.println("Please enter a valid integer");
			return getInput();
		}
		return choice;
		
	}
	
	public double getDoubleInput(){ // allows user to input a double, then gives an error if it's not valid
		Scanner x = new Scanner(System.in);
		System.out.println();
		System.out.print(">>> ");
		double choice = -1;
		if (x.hasNextDouble()){
			choice = x.nextDouble();
		}else{
			System.out.println("Please enter a valid double");
			return getDoubleInput();
		}
		return choice;
		
	}
	
	
	public String getTextInput(){ // allows user to input a string, then gives an error if it's not valid
		Scanner x = new Scanner(System.in);
		System.out.println();
		System.out.print(">>> ");
		String choice = "";
		if (x.hasNextLine()){
			choice = x.nextLine();
		}else{
			System.out.println("Wait.. what? How'd this happen?");
			return getTextInput();
		}
		return choice;
		
	}
	
	public void menuFunction(){ // main menu function that calls most of the other menu functions, runs off of user input
		listOptions(OPTIONS);
		switch(getInput()){
			case 0: displayListSubmenu();
					break;
			case 1: displaySearchSubmenu();
					break;
			case 2: displaySortSubmenu();
					break;
			case 3: addElement();
					break;
			case 4: deleteElement();
					break;
			case 5: printToFile("output.txt");
					break;
			case 6: closeProgram();
					break;
			default: System.out.println("Please select valid option.");
					 menuFunction();
					 break;
		}
	}
	
	public void displaySearchSubmenu(){ // displays the menu specifically for the search function
		clearConsole();
		String[] tempOptions = {"ID Lookup","Name Lookup","Back"};
		listOptions(tempOptions);

		switch(getInput()){
		case 0: clearConsole();
				System.out.println("Please enter an id (int)");
				getSingleItem(idSearch(getInput()));
				break;
		case 1: clearConsole();
				System.out.println("Please enter the name of component to search for (String)");
				getSingleItem(nameSearch(getTextInput()));
				break;
		default: System.out.println("Returning to previous menu.");
				 break;
		}
	}
	
	public void displaySortSubmenu(){ //displays the menu specifically for the sort function
		clearConsole();
		System.out.println("Sort by: ");
		String[] tempOptions = {"ID (asc)","ID (dsc)",
								"Name (asc)","Name (dsc)",
								"Brand (asc)","Brand (dsc)",
								"Price (asc)","Price (dsc)",
								"Average Review (asc)","Average Review (dsc)",
								"Back"};
		listOptions(tempOptions);

		switch(getInput()){
		case 0: clearConsole();
				componentList.sortById();
				break;
		case 1: clearConsole();
				componentList.sortByIdReverse();
				break;
		case 2: clearConsole();
				componentList.sortByName();
				break;
		case 3: clearConsole();
				componentList.sortByNameReverse();
				break;
		case 4: clearConsole();
				componentList.sortByBrand();
				break;
		case 5: clearConsole();
				componentList.sortByBrandReverse();
				break;
		case 6: clearConsole();
				componentList.sortByPrice();
				break;
		case 7: clearConsole();
				componentList.sortByPriceReverse();
				break;
		case 8: clearConsole();
				componentList.sortByReview();
				break;
		case 9: clearConsole();
				componentList.sortByReviewReverse();
				break;
		default: System.out.println("Returning to previous menu.");
				 break;
		}
	}
	
	public void addElement(){ //adds a user-prompted element to the array
		//prompt user for input
		//get user input, store in variable
		//when name, brand, price, and review are stored
		//add new array element with those specifications
		System.out.println("Please enter a Name:");
		String newName = getTextInput();
		System.out.println("Please enter a Brand:");
		String newBrand = getTextInput();
		System.out.println("Please enter a Price:");
		double newPrice = getDoubleInput();
		System.out.println("Please enter a Review:");
		double newReview = getInput();
		RT_MV_Component newComponent = new RT_MV_Component(componentList.getIndex()+1, newName, newBrand, newPrice, (int)newReview); 
		componentList.add(newComponent);
		System.out.println("New component added.");
	}
	
	public void deleteElement(){ //deletes any element from the array based on user input
		System.out.println("Please enter the ID of the component to delete:");
		int position = getInput();			
		if (position < 0 || position > (componentList.getIndex())){
			System.out.println("Invalid ID.");
			//deleteElement();
		}
		else{
			componentList.delete(idSearch(position));
			System.out.println("Component deleted.");
		}
	}
	
	
	
	public int idSearch(int x){
		int tempIndex = -1;
		for (int i = 0; i < componentList.getIndex(); i++){
			if (componentList.getElement(i).getId()==(x)){
				tempIndex=i;
				break;
			}
		}
		return tempIndex;
	}
	
	public int nameSearch(String x){
		int tempIndex = -1;
		for (int i = 0; i < componentList.getIndex(); i++){
			if (componentList.getElement(i).getName().equals(x)){
				tempIndex=i;
				break;
			}
		}
		return tempIndex;
	}
	
	public void getSingleItem(int index){
		if (index >= 0 && index < componentList.getIndex()){
			if (componentList.getElement(index).getClass().equals(RT_MV_GPU.class)){
				System.out.printf("|%5s|%15s|%10s|%10s|%15s|%15s|%10s|%25s|\n","ID","NAME","BRAND","PRICE","REVIEW","BENCHMARK","VRAM","SOCKET");
				for (int i = 0; i < 114; i++){
					System.out.print("#");
				}
				System.out.println();
				System.out.printf("|%5d|%15s|%10s|%10.2f|%15s|%15s|%10.0f|%25s|\n",
						componentList.getElement(index).getId(),
						componentList.getElement(index).getName(),
						componentList.getElement(index).getBrand(),
						componentList.getElement(index).getPrice(),
						componentList.getElement(index).getReviewScore(),
						((RT_MV_GPU) componentList.getElement(index)).getBenchmarkScores(),
						((RT_MV_GPU) componentList.getElement(index)).getClockSpeed(),
						((RT_MV_GPU) componentList.getElement(index)).getSocketType()						
					);
			}
			else if (componentList.getElement(index).getClass().equals(RT_MV_CPU.class)){
				System.out.printf("|%5s|%15s|%10s|%10s|%10s|%15s|%15s|%15s|\n","ID","NAME","BRAND","PRICE","REVIEW","BENCHMARK","CLOCKSPEED","SOCKET");
				for (int i = 0; i < 104; i++){
					System.out.print("#");
				}
				System.out.println();
				System.out.printf(	"|%5d|%15s|%10s|%10.2f|%10d|%15s|%15.2f|%15s|\n",
						componentList.getElement(index).getId(),
						componentList.getElement(index).getName(),
						componentList.getElement(index).getBrand(),
						componentList.getElement(index).getPrice(),
						componentList.getElement(index).getReviewScore(),
						((RT_MV_CPU) componentList.getElement(index)).getBenchmarkScores(),
						((RT_MV_CPU) componentList.getElement(index)).getClockSpeed(),
						((RT_MV_CPU) componentList.getElement(index)).getSocketType()						
					);
			}
			else{
				System.out.printf("|%5s|%15s|%10s|%10s|%10s|\n","ID","NAME","BRAND","PRICE","REVIEW");
				for (int i = 0; i < 56; i++){
					System.out.print("#");
				}System.out.println();
				System.out.printf(	"|%5d|%15s|%10s|%10.2f|%10d|\n",
						componentList.getElement(index).getId(),
						componentList.getElement(index).getName(),
						componentList.getElement(index).getBrand(),
						componentList.getElement(index).getPrice(),
						componentList.getElement(index).getReviewScore()
					);
			}
		}else{
			System.out.println("Unable to find item");
		}
		
	}
	
	public void displayListSubmenu(){
		clearConsole();
		String[] tempOptions = {"GPU Only","CPU Only", "Display All","Back"};
		listOptions(tempOptions);
		switch(getInput()){
			case 0: clearConsole();
					showComponents(0);
					break;
			case 1: clearConsole();
					showComponents(1);
					break;
			case 2: clearConsole();
					showComponents(2);
					break;
			default: System.out.println("Returning to previous menu.");
					break;
		}
	}
	
	public void showComponents(int type){
		
		if (type == 1){
			System.out.printf("|%5s|%15s|%10s|%10s|%10s|%15s|%15s|%15s|\n","ID","NAME","BRAND","PRICE","REVIEW","BENCHMARK","CLOCKSPEED","SOCKET");
			
			for (int i = 0; i < 104; i++){
				System.out.print("#");
			}
			System.out.println();
			
			for (int i = 0; i < componentList.getIndex(); i++){
				if (componentList.getElement(i).getClass()==RT_MV_CPU.class){
					System.out.printf(	"|%5d|%15s|%10s|%10.2f|%10d|%15s|%15.2f|%15s|\n",
							componentList.getElement(i).getId(),
							componentList.getElement(i).getName(),
							componentList.getElement(i).getBrand(),
							componentList.getElement(i).getPrice(),
							componentList.getElement(i).getReviewScore(),
							((RT_MV_CPU) componentList.getElement(i)).getBenchmarkScores(),
							((RT_MV_CPU) componentList.getElement(i)).getClockSpeed(),
							((RT_MV_CPU) componentList.getElement(i)).getSocketType()						
						);
				}	
			}
		}else if (type == 0){
			System.out.printf("|%5s|%15s|%10s|%10s|%15s|%15s|%10s|%25s|\n","ID","NAME","BRAND","PRICE","REVIEW","BENCHMARK","VRAM","SOCKET");

			for (int i = 0; i < 114; i++){
				System.out.print("#");
			}
			System.out.println();
			
			for (int i = 0; i < componentList.getIndex(); i++){
				if (componentList.getElement(i).getClass()==RT_MV_GPU.class){
					System.out.printf("|%5d|%15s|%10s|%10.2f|%15s|%15s|%10.0f|%25s|\n",
							componentList.getElement(i).getId(),
							componentList.getElement(i).getName(),
							componentList.getElement(i).getBrand(),
							componentList.getElement(i).getPrice(),
							componentList.getElement(i).getReviewScore(),
							((RT_MV_GPU) componentList.getElement(i)).getBenchmarkScores(),
							((RT_MV_GPU) componentList.getElement(i)).getClockSpeed(),
							((RT_MV_GPU) componentList.getElement(i)).getSocketType()						
						);
				}
			}
		}else{
			System.out.printf("|%5s|%15s|%10s|%10s|%10s|\n","ID","NAME","BRAND","PRICE","REVIEW");
			
			for (int i = 0; i < 56; i++){
				System.out.print("#");
			}System.out.println();
			
			for (int i = 0; i < componentList.getIndex(); i++){
				
				System.out.printf(	"|%5d|%15s|%10s|%10.2f|%10d|\n",
									componentList.getElement(i).getId(),
									componentList.getElement(i).getName(),
									componentList.getElement(i).getBrand(),
									componentList.getElement(i).getPrice(),
									componentList.getElement(i).getReviewScore()
								);
			}
		}
	}
	
	public void displayWelcomeMessage(){ // displays the welcome message when the program is first run
		System.out.println("Welcome to ComponentComparisons!");
		System.out.println("Made By: Markiyan Varhola and Ryan Tan");
		System.out.println("CS201 Final Project");
		System.out.println("Version 1.0");
		for (int i = 0; i < 10; i++){
			System.out.print("-");
		}
		System.out.println();
	}
	
	public void clearConsole(){ // prints out 100 lines to "clear" the console so there's no clutter when changing menus
		for (int i = 0; i < 100; i++){
			System.out.println();
		}
	}
	
	
	public void closeProgram(){ // prints the closing message and sets the closing boolean to true, ending the program
		System.out.println("Thank you for using ComponentComparisons!");
		done = true;
	}

	public void printToFile(String filename){
		
		PrintWriter w;
		try {
			w = new PrintWriter(filename, "UTF-8");
			w.printf("\nAll Components\n");
			w.printf("|%5s|%15s|%10s|%10s|%10s|\n","ID","NAME","BRAND","PRICE","REVIEW");
			
			for (int i = 0; i < 56; i++){
				w.print("#");
			}w.println();
			
			for (int i = 0; i < componentList.getIndex(); i++){
				
				w.printf(	"|%5d|%15s|%10s|%10.2f|%10d|\n",
							componentList.getElement(i).getId(),
							componentList.getElement(i).getName(),
							componentList.getElement(i).getBrand(),
							componentList.getElement(i).getPrice(),
							componentList.getElement(i).getReviewScore()
						);
			}
			w.printf("\nGPU List\n");
			

			w.printf("|%5s|%15s|%10s|%10s|%15s|%15s|%10s|%25s|\n","ID","NAME","BRAND","PRICE","REVIEW","BENCHMARK","VRAM","SOCKET");

			for (int i = 0; i < 114; i++){
				w.print("#");
			}
			w.println();
			
			for (int i = 0; i < componentList.getIndex(); i++){
				if (componentList.getElement(i).getClass()==RT_MV_GPU.class){
					w.printf("|%5d|%15s|%10s|%10.2f|%15s|%15s|%10.0f|%25s|\n",
							componentList.getElement(i).getId(),
							componentList.getElement(i).getName(),
							componentList.getElement(i).getBrand(),
							componentList.getElement(i).getPrice(),
							componentList.getElement(i).getReviewScore(),
							((RT_MV_GPU) componentList.getElement(i)).getBenchmarkScores(),
							((RT_MV_GPU) componentList.getElement(i)).getClockSpeed(),
							((RT_MV_GPU) componentList.getElement(i)).getSocketType()						
						);
				}
			}
			
			w.printf("\nCPU LIST\n");
			
			w.printf("|%5s|%15s|%10s|%10s|%10s|%15s|%15s|%15s|\n","ID","NAME","BRAND","PRICE","REVIEW","BENCHMARK","CLOCKSPEED","SOCKET");
			
			for (int i = 0; i < 104; i++){
				w.print("#");
			}
			w.println();
			
			for (int i = 0; i < componentList.getIndex(); i++){
				if (componentList.getElement(i).getClass()==RT_MV_CPU.class){
					w.printf(	"|%5d|%15s|%10s|%10.2f|%10d|%15s|%15.2f|%15s|\n",
							componentList.getElement(i).getId(),
							componentList.getElement(i).getName(),
							componentList.getElement(i).getBrand(),
							componentList.getElement(i).getPrice(),
							componentList.getElement(i).getReviewScore(),
							((RT_MV_CPU) componentList.getElement(i)).getBenchmarkScores(),
							((RT_MV_CPU) componentList.getElement(i)).getClockSpeed(),
							((RT_MV_CPU) componentList.getElement(i)).getSocketType()						
						);
				}	
			}
			
			System.out.println("Printed contents to: "+filename);
			w.close();
		
		} catch (FileNotFoundException e) {
			System.out.println("Unable to find/create file.");
		} catch (UnsupportedEncodingException e) {
			System.out.println("Error: unsupported encoding.");
		}
		
		}
		
}
	

