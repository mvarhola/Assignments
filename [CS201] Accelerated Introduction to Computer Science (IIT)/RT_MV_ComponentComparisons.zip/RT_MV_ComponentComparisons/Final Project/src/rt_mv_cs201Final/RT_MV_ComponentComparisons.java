package rt_mv_cs201Final;
/* Markiyan Varhola and Ryan S. Tan
 * CS 201 Spring 2015
 * Final Project
 * April 13, 2015
 */
//DOCUMENTATION - This Java program is built for computer hardware shoppers. It offers quick ways to sort and search through a pre-created
//list of computer components, add and delete their own user-created components, and even write an output to file.
//This class is the main application class that uses all the others.  
public class RT_MV_ComponentComparisons {

	public static void main(String[] args) {
		RT_MV_Menu menu = new RT_MV_Menu("components.txt"); //reading from input file
		
		menu.displayWelcomeMessage(); //displays the welcome message
		
		while (!menu.getProgramStatus()){ //checks the done boolean in the Menu class
			// main menu
			menu.menuFunction(); //perform menu function, handled by Menu class
		}
	}

}
