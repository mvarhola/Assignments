package com.cs442.mvarhola.l6foodorderapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class AdminAddItem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_item);
    }
}
