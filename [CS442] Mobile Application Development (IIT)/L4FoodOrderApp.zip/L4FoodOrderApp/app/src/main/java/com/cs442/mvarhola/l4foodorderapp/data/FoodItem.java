package com.cs442.mvarhola.l4foodorderapp.data;

/**
 * Created by p0rt on 9/21/17.
 */

public class FoodItem {
    public int id;
    public String name;
    public double price;
    public int amount;

    public FoodItem(int id, String name, double price, int amount) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.amount = amount;
    }

}
