package com.cs442.mvarhola.l4foodorderapp.data;

/**
 * Created by p0rt on 9/20/17.
 */

public class Food {

    public static String[] foodMenu = {
            "Big Pizza",
            "Frozen Pineapple",
            "Garlic Pizza",
            "Oatmeal Pizza"
    };

    public static String[] foodDetails = {
            "This pizza is seriously big. Extremely Big. And not even that good. But its big.",
            "You just put a pineapple in the freezer and what you see is what you get. Frozen pineapple.",
            "We tossed some garlic on a frozen pizza and this is our signature dish. Your breath will smell.",
            "Please don't order this item. It is cursed and anyone who orders it will not survive the taste."
    };

    public static double[] foodPrices = {
            19.99,
            12.99,
            2.99,
            41.99
    };

    public String getString(){
        String itemString = "";
        itemString += " ";


        return itemString;
    }
}
