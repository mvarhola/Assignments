package com.cs442.mvarhola.l4foodorderapp.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.Button;

import com.cs442.mvarhola.l4foodorderapp.R;
import com.cs442.mvarhola.l4foodorderapp.data.Food;


public class OrderMenuFragment extends Fragment implements View.OnClickListener {
    int position = 0;

    Button orderButton;
    Button resetButton;
    TextView totalAmount;

    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(savedInstanceState == null){
            if(getArguments() != null) {
                position = getArguments().getInt("position", 0);
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {

        View rootView =  inflater.inflate(R.layout.fragment_order_menu, parent, false);

        orderButton = (Button) rootView.findViewById(R.id.order_button);
        resetButton = (Button) rootView.findViewById(R.id.reset_order_button);
        totalAmount = (TextView) rootView.findViewById(R.id.total_amount_text);

        orderButton.setOnClickListener(this);
        resetButton.setOnClickListener(this);

        return rootView;
    }

    public void update(){
        totalAmount.setText(Double.toString(calcTotal()));
    }

    public double calcTotal(){

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());

        double total = 0.00;

        for (int i = 0; i < Food.foodMenu.length; i++) {
            double cost = Food.foodPrices[i];
            double amount = 0.00;

            if (preferences.contains(Integer.toString(i))){
                amount = Integer.parseInt(preferences.getString(Integer.toString(i), ""));
            }else{
                amount = 0.00;
            }
            total += cost*amount;
        }

        return total;
    }

    @Override
    public void onClick(View rootView) {
        switch (rootView.getId()) {
            case R.id.order_button:
                onPlaceOrder();
            case R.id.reset_order_button:
                onResetOrder();
                break;
        }
    }

    public void clearPreferences(){
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.commit();
    }

    public void onPlaceOrder(){
        Toast.makeText(getActivity(),"Order placed!",Toast.LENGTH_SHORT).show();

    }

    public void onResetOrder(){

        Toast.makeText(getActivity(),"Order Reset!",Toast.LENGTH_SHORT).show();

    }


}
